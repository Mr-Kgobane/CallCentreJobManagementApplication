package com.example.CallCenter.Model;

import jakarta.persistence.*;


import java.util.Date;

@Entity
@Table
public class Job {
    public Job() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int JobID;
    private String JobType;
    private String Status;
    private String JobDescription;
    private Date ScheduledDate;
    private int ClientID;
    private int CallAgentID;
    private int TechnicianID;
    private int ContractID;
    private int ManagerID;

    public int getJobID() {
        return JobID;
    }

    public void setJobID(int jobID) {
        JobID = jobID;
    }

    public String getJobType() {
        return JobType;
    }

    public void setJobType(String jobType) {
        JobType = jobType;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getJobDescription() {
        return JobDescription;
    }

    public void setJobDescription(String jobDescription) {
        JobDescription = jobDescription;
    }

    public Date getScheduledDate() {
        return ScheduledDate;
    }

    public void setScheduledDate(Date scheduledDate) {
        ScheduledDate = scheduledDate;
    }

    public int getClientID() {
        return ClientID;
    }

    public void setClientID(int clientID) {
        ClientID = clientID;
    }

    public int getCallAgentID() {
        return CallAgentID;
    }

    public void setCallAgentID(int callAgentID) {
        CallAgentID = callAgentID;
    }

    public int getTechnicianID() {
        return TechnicianID;
    }

    public void setTechnicianID(int technicianID) {
        TechnicianID = technicianID;
    }

    public int getContractID() {
        return ContractID;
    }

    public void setContractID(int contractID) {
        ContractID = contractID;
    }

    public int getManagerID() {
        return ManagerID;
    }

    public void setManagerID(int managerID) {
        ManagerID = managerID;
    }
}
