package com.example.CallCenter.PresentationLayer;

import com.example.CallCenter.BusinessLogicLayer.CallCenterService;
import com.example.CallCenter.Model.CallRecord;
import com.example.CallCenter.Model.Job;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/callcenter")
public class CallCenterController {
    @Autowired
    private CallCenterService callCenterService;

    @PostMapping("/addrecord")
    public String add(@RequestBody CallRecord callRecord){
        callCenterService.saveCallRecord(callRecord);
        return "call recorded";
    }
    @PostMapping("/addjon")
    public String add(@RequestBody Job job){
        callCenterService.recordJob(job);
        return "job recorded";
    }
    @GetMapping("/getallrecords")
    public List<CallRecord> getAllCallRecords(){
        return callCenterService.getAllCallRecords();
    };
    @GetMapping("/getalljobs")
    public List<Job> getAllJobs(){
        return callCenterService.getallJobs();
    };
}
