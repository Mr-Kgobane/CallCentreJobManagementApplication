package com.example.CallCenter.BusinessLogicLayer;

import com.example.CallCenter.Model.CallRecord;
import com.example.CallCenter.Model.Job;

import java.util.List;

public interface CallCenterService {
    public void Callmessagesms( CallRecord callRecord)
    public CallRecord saveCallRecord(CallRecord callRecord);
    public Job recordJob(Job job);
    public List<CallRecord> getAllCallRecords();
    public List<Job> getallJobs();
}
