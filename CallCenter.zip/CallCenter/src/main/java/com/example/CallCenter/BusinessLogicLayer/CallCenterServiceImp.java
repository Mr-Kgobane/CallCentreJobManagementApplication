package com.example.CallCenter.BusinessLogicLayer;

import com.example.CallCenter.Model.CallRecord;
import com.example.CallCenter.Model.Job;
import com.example.CallCenter.Repositories.CallRecordRepo;
import com.example.CallCenter.Repositories.JobRepo;
import org.springframework.beans.factory.annotation.Autowired;


import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CallCenterServiceImp implements CallCenterService {

    @Autowired
    private CallRecordRepo callRecordRepo;
    @Autowired
    private JobRepo jobRepo;




        // Find your Account Sid and Token at console.twilio.com
        public static final String ACCOUNT_SID = "AC665151e7fe0982292be8852bca606b33";
        public static final String AUTH_TOKEN = "f340115d86689d4f624e5006d19e4ab2";
        @Override
        public void Callmessagesms( CallRecord callRecord){
            Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

            // Your Twilio phone number
            PhoneNumber from = new PhoneNumber("+16562163296");

            // Recipient's phone number
            PhoneNumber to = new PhoneNumber("+27644286071");

            // Message to send
            String messageBody = "Hello,\n NEW request by"+callRecord.getClientID()+",\nRecord:"+callRecord.getTimestamp()+",\nProblem:"+callRecord.getProblemDetails();

            // Send the SMS
            Message message = Message.creator(to, from, messageBody).create();

            System.out.println("Message sent with SID: " + message.getSid());
        }
    @Override
    public CallRecord saveCallRecord(CallRecord callRecord) {
        return callRecordRepo.save(callRecord);
    }

    @Override
    public Job recordJob(Job job) {
        return jobRepo.save(job);
    }

    @Override
    public List<CallRecord> getAllCallRecords() {
        return callRecordRepo.findAll();
    }

    @Override
    public List<Job> getallJobs() {
        return jobRepo.findAll();
    }
}
