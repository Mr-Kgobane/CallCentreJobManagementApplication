package com.example.CallCenter.Model;


import jakarta.persistence.*;

import java.sql.Timestamp;

@Entity
@Table
public class CallRecord {
    public CallRecord() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int CallID;

    public int getCallID() {
        return CallID;
    }

    public void setCallID(int callID) {
        CallID = callID;
    }

    public int getClientID() {
        return ClientID;
    }

    public void setClientID(int clientID) {
        ClientID = clientID;
    }

    public java.sql.Timestamp getTimestamp() {
        return Timestamp;
    }

    public void setTimestamp(java.sql.Timestamp timestamp) {
        Timestamp = timestamp;
    }

    public String getProblemDetails() {
        return ProblemDetails;
    }

    public void setProblemDetails(String problemDetails) {
        ProblemDetails = problemDetails;
    }

    private int ClientID;
    private java.sql.Timestamp Timestamp;
    private String ProblemDetails;
}
