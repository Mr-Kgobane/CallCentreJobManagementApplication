package com.example.CallCenter.Model;

import java.sql.Timestamp;

public class Login {

}
