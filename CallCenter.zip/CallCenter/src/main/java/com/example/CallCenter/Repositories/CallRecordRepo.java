package com.example.CallCenter.Repositories;

import com.example.CallCenter.Model.CallRecord;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CallRecordRepo extends JpaRepository<CallRecord,Integer> {
}
