package com.example.CallCenter.Repositories;

import com.example.CallCenter.Model.Job;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobRepo extends JpaRepository<Job,Integer> {
}
