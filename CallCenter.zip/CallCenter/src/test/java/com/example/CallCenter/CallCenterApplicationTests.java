package com.example.CallCenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CallCenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
